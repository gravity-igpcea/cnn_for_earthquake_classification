import numpy as np
import glob,re
import obspy
from obspy.core import Stream,read,UTCDateTime
import matplotlib.pyplot as plt 
import matplotlib.image as mpimg
from pylab import *
import pandas as pd

#fig = plt.figure()
#singlechannel.plot(type='dayplot')
st = Stream()
times_csv = {}
times_csv = {
                "event_starttime": [],
                "event_starttimestamp": [],                   
                     }
for file in glob.glob('./*.mseed'):
    st = read(file)
    tr=st[0]
    file1 = re.split('/',  file)
    fname=file1[-1]+'.png'
    #st.plot(outfile=fname,format='png',type="dayplot", interval=15, right_vertical_labels=False,
    #    vertical_scaling_range=None, one_tick_per_line=True,number_of_ticks=30,
    #    color=['k', 'r', 'b', 'g'], show_y_UTC_label=False,show=False)
    tr.slice(tr.stats.starttime,tr.stats.starttime+21600).plot(outfile="XX.MXI_dayplot_0.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True,events=[{"time": UTCDateTime("2008-07-25T00:45:17"), "text": "Event A"}])
    tr.slice(tr.stats.starttime+21600,tr.stats.starttime+43200).plot(outfile="XX.MXI_dayplot_21600.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)
    tr.slice(tr.stats.starttime+43200,tr.stats.starttime+64800).plot(outfile="XX.MXI_dayplot_43200.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)
    tr.slice(tr.stats.starttime+64800,tr.stats.endtime).plot(outfile="XX.MXI_dayplot_64800.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)
    #st.plot(outfile=fname,format='png',type="dayplot")
    #tr.plot(outfile=fname,format='png',type='dayplot',show=False)
    #tr1 = st1[0]
for file1 in glob.glob('XX.MXI_dayplot_?.png'):
    fname=file1+'.txt'
    img=mpimg.imread(file1)
    plt.imshow(img) 
    print ('Please click 3 points')
    x =ginput(-1,timeout=0) 
    print ('you clicked:',x) 
    #show()
    fileObject = open(fname, 'w')  
    fileObject.write("x_cordinate,y_cordinate,stname\n")
    for ip in x:  
        print ip,ip[0],ip[1]
        fileObject.write(str(ip)+',')
        fileObject.write(file1)  
        fileObject.write('\n')  
    fileObject.close()
for file2 in glob.glob('XX.MXI_dayplot_?.png.txt'):
    dayplot_csv=pd.read_csv(file2)
    for values_n in range(dayplot_csv.shape[0]):
        x_cordinate = dayplot_csv.x_cordinate.values[values_n]
        print x_cordinate
        y_cordinate = dayplot_csv.y_cordinate.values[values_n]+10
        tstart=dayplot_csv.stname.values[values_n].split(".png")[0].split("_")[-1]
        print starttime
        lenx=509.8  #the length of the png figure x range
        leny=607.8  #the length of the png figure y range
        
        xstart=96   #the upleft corner point(xstart,ystart)
        ystart=30
        time_interval_x=900  # x axis time
        time_interval_y=25   # y axis time
        tx=(x_cordinate-xstart)/lenx * time_interval_x
        ty=int((y_cordinate-ystart)/leny * time_interval_y-1)*time_interval_x
        print ty
        t=UTCDateTime("2008-07-25T00:00:00")+tstart + ty + tx
        tstamp=t.timestamp
        times_csv["event_starttime"].append(t)
        times_csv["event_starttimestamp"].append(tstamp)
df = pd.DataFrame.from_dict(times_csv)
print (df.shape[0])
#output_catalog = os.path.join(args.output,'XX_MXI_2008_07_25_sta_cnn.csv')
df.to_csv('XX_MXI_2008_07_25_sta_cnn.csv')

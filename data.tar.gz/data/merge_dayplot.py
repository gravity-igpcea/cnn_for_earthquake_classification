import numpy as np
import glob
import obspy
from obspy.core import Stream,read
import matplotlib.pyplot as plt 
import matplotlib.image as mpimg
from pylab import *
st = Stream()
for file in glob.glob('*mseed'):
    st += read(file)
st.sort(['starttime'])
st[0:int(len(st)/4)].plot(outfile="XX.MXI_dayplot_1.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)

st[int(len(st)/4):int(len(st)/2)].plot(outfile="XX.MXI_dayplot_2.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)
st[int(len(st)/2):int(3*len(st)/4)].plot(outfile="XX.MXI_dayplot_3.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)
st[int(3*len(st)/4):int(len(st))].plot(outfile="XX.MXI_dayplot_4.png",format='png',type="dayplot",right_vertical_labels=True, one_tick_per_line=True,show_y_UTC_label=True)
st.merge(method=0,interpolation_samples=0, fill_value=None)
#for tr in st:
#    if isinstance(tr.data,np.ma.masked_array):
#        tr.data=tr.data.filled()
#st.write('../positive_sample.mseed',format="mseed")
#st.plot(outfile="XX.MXI_dayplot.png",format='png',type="dayplot", interval=60, right_vertical_labels=False,
#        vertical_scaling_range=None, one_tick_per_line=True,number_of_ticks=120,
#        color=['k', 'r', 'b', 'g'], show_y_UTC_label=False,show=False)
#st.plot(outfile="XX.MXI_dayplot.png",format='png',type="dayplot",vertical_scaling_range=10e3)
for tr in st:
    tr.normalize()
st.plot(outfile="XX.MXI_dayplot_norm.png",format='png',type="dayplot",vertical_scaling_range=10e-1)
for file1 in glob.glob('XX.MXI_dayplot_?.png'):
    fname=file1+'.txt'
    img=mpimg.imread(file1)
    plt.imshow(img) 
    print ('Please click 3 points')
    x =ginput(-1,timeout=0) 
    print ('you clicked:',x) 
    #show()
    fileObject = open(fname, 'w')  
    for ip in x:  
        fileObject.write(str(ip)+',')
        fileObject.write(file1)  
        fileObject.write('\n')  
    fileObject.close()
